import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modulea',
  templateUrl: './modulea.component.html',
  styleUrls: ['./modulea.component.css']
})
export class ModuleaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

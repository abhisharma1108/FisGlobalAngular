import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moduleb',
  templateUrl: './moduleb.component.html',
  styleUrls: ['./moduleb.component.css']
})
export class ModulebComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

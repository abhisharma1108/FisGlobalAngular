import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-use-custom-pipe',
  templateUrl: './use-custom-pipe.component.html',
  styleUrls: ['./use-custom-pipe.component.css']
})
export class UseCustomPipeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  Name  : string ="ABHISHEK SHARMA"
  today : number = Date.now();
  msg : string = "This is demo text"


  products = [
    { id: 'PROD1001', name: "Laptop", price: 67000, description: 'HP Elite Book' },
    { id: 'PROD1002', name: "SSD", price: 4500, description: 'SEGATE SSD 500GB' },
    { id: 'PROD1003', name: "PEN DRIVE", price: 650, description: 'HP 3.0 64 GB' },
    { id: 'PROD1004', name: "DESKTOP", price: 35000, description: 'HP PAVALION' },
    { id: 'PROD1005', name: "PRINTER", price: 3000, description: 'HP DESKJET 1020' }
  ]

}

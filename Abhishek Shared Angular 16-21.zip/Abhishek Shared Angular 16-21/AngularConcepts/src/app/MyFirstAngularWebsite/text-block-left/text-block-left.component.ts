import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-block-left',
  templateUrl: './text-block-left.component.html',
  styleUrls: ['./text-block-left.component.css']
})
export class TextBlockLeftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from } from 'rxjs';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HttpUtilityServiceService {

  constructor(private http: HttpClient) { }
  GetUserDetails(): Observable<any> {
    return this.http.get('https://jsonplaceholder.typicode.com/users');

  }
}

import { Component, OnInit } from '@angular/core';
import { Product } from '../../InputAndOutputDecoratorDemo/InputDecoratorDemo/product/product/product.module';
import { UtilityServiceService } from '../utility-service.service';
@Component({
  selector: 'app-consume-utlity-service',
  templateUrl: './consume-utlity-service.component.html',
  styleUrls: ['./consume-utlity-service.component.css']
})
export class ConsumeUtlityServiceComponent implements OnInit {

  constructor(private _msgService : UtilityServiceService) {
    this.product=new Product();
   }
   productName : string = "";
  product : Product ;
  productList:Product[]=[];

  ngOnInit(): void {
    this.productName = this._msgService.ProductName;
    this.product = this._msgService.Product;
    this.productList = this._msgService.products;
  }
  btnClick(){
    // const msgSrv = new MessageService();
    // msgSrv.ShowMessage();
    this._msgService.ShowMessage();
    
  }

 
}

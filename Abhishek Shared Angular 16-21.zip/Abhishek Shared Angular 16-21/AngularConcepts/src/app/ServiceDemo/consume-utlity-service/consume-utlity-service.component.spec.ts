import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumeUtlityServiceComponent } from './consume-utlity-service.component';

describe('ConsumeUtlityServiceComponent', () => {
  let component: ConsumeUtlityServiceComponent;
  let fixture: ComponentFixture<ConsumeUtlityServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsumeUtlityServiceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsumeUtlityServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsumeHttpUtlityServiceComponent } from './consume-http-utlity-service.component';

describe('ConsumeHttpUtlityServiceComponent', () => {
  let component: ConsumeHttpUtlityServiceComponent;
  let fixture: ComponentFixture<ConsumeHttpUtlityServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsumeHttpUtlityServiceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConsumeHttpUtlityServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

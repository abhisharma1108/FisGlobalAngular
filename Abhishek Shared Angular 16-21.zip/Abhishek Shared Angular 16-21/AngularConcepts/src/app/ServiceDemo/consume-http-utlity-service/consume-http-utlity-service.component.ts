import { Component, OnInit } from '@angular/core';
import { HttpUtilityServiceService } from '../http-utility-service.service';
@Component({
  selector: 'app-consume-http-utlity-service',
  templateUrl: './consume-http-utlity-service.component.html',
  styleUrls: ['./consume-http-utlity-service.component.css']
})
export class ConsumeHttpUtlityServiceComponent implements OnInit {

  constructor(private httpSer: HttpUtilityServiceService ) { }
  Users:any;

  ngOnInit(): void {
    this.Users = this.httpSer.GetUserDetails().subscribe(user=>this.Users=user);

  }

}

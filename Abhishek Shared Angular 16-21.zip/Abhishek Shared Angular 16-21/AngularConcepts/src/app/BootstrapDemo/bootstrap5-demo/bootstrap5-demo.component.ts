import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap5-demo',
  templateUrl: './bootstrap5-demo.component.html',
  styleUrls: ['./bootstrap5-demo.component.css']
})
export class Bootstrap5DemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

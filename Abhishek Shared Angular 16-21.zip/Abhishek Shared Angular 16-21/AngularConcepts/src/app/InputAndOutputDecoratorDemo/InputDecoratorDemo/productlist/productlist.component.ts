import { Component, Input, OnInit } from '@angular/core';
import { Product } from '../product/product/product.module';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  @Input() product : Product;
  constructor() {
    this.product= new Product();
   }

  ngOnInit(): void {
  }

}

import { importProvidersFrom, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopNavbarComponent } from './MyFirstAngularWebsite/top-navbar/top-navbar.component';
import { TextBlockLeftComponent } from './MyFirstAngularWebsite/text-block-left/text-block-left.component';
import { TextBlockRightComponent } from './MyFirstAngularWebsite/text-block-right/text-block-right.component';
import { Bootstrap5DemoComponent } from './BootstrapDemo/bootstrap5-demo/bootstrap5-demo.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbootstrapdemoComponent } from './BootstrapDemo/ngbootstrapdemo/ngbootstrapdemo.component';
import { OneWayBindingComponent } from './BindingsDemo/one-way-binding/one-way-binding.component';
import { EventBindingComponent } from './BindingsDemo/event-binding/event-binding.component';
import { TwoWayBindingComponent } from './BindingsDemo/two-way-binding/two-way-binding.component';
import { FormsModule } from '@angular/forms';
import { NgIfDemoComponent } from './AttributeDirectivesDemo/ng-if-demo/ng-if-demo.component';
import { NgSwitchDemoComponent } from './AttributeDirectivesDemo/ng-switch-demo/ng-switch-demo.component';
import { NgForDemoComponent } from './AttributeDirectivesDemo/ng-for-demo/ng-for-demo.component';
import { RouterModule, Routes } from '@angular/router';
import { PushSpliceWithForDemoComponent } from './push-splice-with-for-demo/push-splice-with-for-demo.component';
import { AngularPipeDemoComponent } from './PipeDemo/angular-pipe-demo/angular-pipe-demo.component';
import { reverseStrPipe } from './PipeDemo/custom-pipe.pipe';
import { UseCustomPipeComponent } from './PipeDemo/use-custom-pipe/use-custom-pipe.component';
import { ProductComponent } from './InputAndOutputDecoratorDemo/InputDecoratorDemo/product/product.component';
import { ProductlistComponent } from './InputAndOutputDecoratorDemo/InputDecoratorDemo/productlist/productlist.component';
import { ChildComponent } from './InputAndOutputDecoratorDemo/OutpuDecoratorDemo/child/child.component';
import { ParentComponent } from './InputAndOutputDecoratorDemo/OutpuDecoratorDemo/parent/parent.component';
import { ConsumeUtlityServiceComponent } from './ServiceDemo/consume-utlity-service/consume-utlity-service.component';
import { HttpClientModule } from '@angular/common/http';
import { ConsumeHttpUtlityServiceComponent } from './ServiceDemo/consume-http-utlity-service/consume-http-utlity-service.component';

const appRoutes: Routes = [
  { path: 'Header', component: HeaderComponent },
  { path: 'Bootstrap5Demo', component: Bootstrap5DemoComponent },
  { path: 'OneWayBinding', component: OneWayBindingComponent },
  { path: 'TwoWayBinding', component: TwoWayBindingComponent },
  { path: 'EventBinding', component: EventBindingComponent },
  { path: 'NgForDemo', component: NgForDemoComponent },
  { path: 'PushSpliceWithForDemo', component: PushSpliceWithForDemoComponent },
  { path: 'AngularPipeDemo', component: AngularPipeDemoComponent },
  { path: 'UseCustomPipe', component: UseCustomPipeComponent },
  { path: 'Product', component: ProductComponent },
  { path: 'Parent', component: ParentComponent },
  { path: 'ConsumeUtlityService', component: ConsumeUtlityServiceComponent },
  { path: 'ConsumeHttpUtlityService', component: ConsumeHttpUtlityServiceComponent }


]
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopNavbarComponent,
    TextBlockLeftComponent,
    TextBlockRightComponent,
    Bootstrap5DemoComponent,
    NgbootstrapdemoComponent,
    OneWayBindingComponent,
    EventBindingComponent,
    TwoWayBindingComponent,
    NgIfDemoComponent,
    NgSwitchDemoComponent,
    NgForDemoComponent,
    PushSpliceWithForDemoComponent,
    AngularPipeDemoComponent,
    reverseStrPipe,
    UseCustomPipeComponent,
    ProductComponent,
    ProductlistComponent,
    ChildComponent,
    ParentComponent,
    ConsumeUtlityServiceComponent,
    ConsumeHttpUtlityServiceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {Routes,Router, RouterModule} from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import{ HttpClientModule}from '@angular/common/http'
import { AppComponent } from './app.component';
import { TemplateDrivenFromDemoComponent } from './AngularFormsDemo/template-driven-from-demo/template-driven-from-demo.component';
import { ReactiveDrivenFromDemoComponent } from './AngularFormsDemo/reactive-driven-from-demo/reactive-driven-from-demo.component';
import { FormBuilderDemoComponent } from './AngularFormsDemo/form-builder-demo/form-builder-demo.component';
import { AddUserComponent } from './CrudUserWithWebAPI/add-user/add-user.component';
import { UserListComponent } from './CrudUserWithWebAPI/user-list/user-list.component';
import { UpdateUserComponent } from './CrudUserWithWebAPI/update-user/update-user.component';
import { DeleteUserComponent } from './CrudUserWithWebAPI/delete-user/delete-user.component';
import { DetailsUserComponent } from './CrudUserWithWebAPI/details-user/details-user.component';
const  appRoutes: Routes=[
  {path:'AddUser',component:AddUserComponent},
  {path:'UsersList',component:UserListComponent},
  {path:'UpdateUser/:id',component:UpdateUserComponent},
  {path:'DeleteUser',component:DeleteUserComponent},
  {path:'DetailsUser',component:DetailsUserComponent}
]


@NgModule({
  declarations: [
    AppComponent,
    TemplateDrivenFromDemoComponent,
    ReactiveDrivenFromDemoComponent,
    FormBuilderDemoComponent,
    AddUserComponent,
    UserListComponent,
    UpdateUserComponent,
    DeleteUserComponent,
    DetailsUserComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

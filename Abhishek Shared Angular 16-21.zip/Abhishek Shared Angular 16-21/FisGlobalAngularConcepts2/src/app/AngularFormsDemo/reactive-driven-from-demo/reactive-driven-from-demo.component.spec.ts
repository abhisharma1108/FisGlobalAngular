import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveDrivenFromDemoComponent } from './reactive-driven-from-demo.component';

describe('ReactiveDrivenFromDemoComponent', () => {
  let component: ReactiveDrivenFromDemoComponent;
  let fixture: ComponentFixture<ReactiveDrivenFromDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReactiveDrivenFromDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReactiveDrivenFromDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

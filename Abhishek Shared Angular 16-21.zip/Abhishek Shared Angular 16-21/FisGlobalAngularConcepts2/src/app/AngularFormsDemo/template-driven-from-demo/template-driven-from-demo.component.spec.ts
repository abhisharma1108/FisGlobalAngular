import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateDrivenFromDemoComponent } from './template-driven-from-demo.component';

describe('TemplateDrivenFromDemoComponent', () => {
  let component: TemplateDrivenFromDemoComponent;
  let fixture: ComponentFixture<TemplateDrivenFromDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TemplateDrivenFromDemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TemplateDrivenFromDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

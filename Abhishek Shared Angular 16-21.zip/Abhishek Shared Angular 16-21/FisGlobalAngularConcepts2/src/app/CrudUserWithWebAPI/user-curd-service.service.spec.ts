import { TestBed } from '@angular/core/testing';

import { UserCurdServiceService } from './user-curd-service.service';

describe('UserCurdServiceService', () => {
  let service: UserCurdServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserCurdServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

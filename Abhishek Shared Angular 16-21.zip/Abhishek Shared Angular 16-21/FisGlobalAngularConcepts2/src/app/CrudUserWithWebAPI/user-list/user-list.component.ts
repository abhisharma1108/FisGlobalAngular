import { Component, OnInit } from '@angular/core';
import { UserCurdServiceService } from '../user-curd-service.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  constructor(private userservice: UserCurdServiceService) { }
  UserList: any = [];

  ngOnInit(): void {
    this.userservice.getList().subscribe((result) => {
      console.warn(result)
      this.UserList = result;
    })

  }

  deleteUser(id:any) {
    //Note : This data we have delete it from collection array also.
    this.UserList.splice(id - 1, 1)
    this.userservice.DeleteUser(id).subscribe((result) => {
      console.warn(result)
    })
  }

}

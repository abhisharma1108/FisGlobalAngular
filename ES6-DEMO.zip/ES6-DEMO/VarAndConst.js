// for(var x=1;x<=10;x++){} //global
// console.log(x);

// for(let x=1;x<=10;x++){} 
// console.log(x);// It's having locally define

let firstName = 'Abhishek';
let lastName = 'Sharma';
lastName = 'Abhisharma';

let age = 999;
let birthDate = new Date();

let person = {
firstName : 'Abhishek',
lastName: 'Sharma'
}
//console.log(person.firstName);
// let duplicate = function(value){
//     return value*2;
// }

// //console.log(duplicate(5));

// //CONST


// const person2 = {
//     firstName : 'Abhishek',
//     lastName: 'Sharma'
//     }
// person2.firstName = 'Abhi';
// person2.firstName = 'Abhishek'; // allow to when in array or object
// const personName = 'Abhishek Sharma';
// personName = 'Abhee';//Assignment to constant variable.

//  console.log(personName);
// //person2 = {} Assignment to constant variable.

// console.log(person2);

//myarrya : [] // collection
//myobj : {} // object//












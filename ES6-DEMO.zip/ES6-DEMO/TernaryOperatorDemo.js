const age = 17;
let message
if (age >= 18) {
message = "You can go to cool age";
}
else
{
 message = 'You go to iskool';   
}
//Same we can have with ternary operator
message = (age>=18) ? "You are major" : "You are minor";

console.log(message);


class Rectangle {
    constructor(height, width) {
      //(this.height = height),
      this.width = width;
    }
  }
  const rectangleobj = new Rectangle(7, 5);
  console.log(rectangleobj.height); //undefined
  
  class Rectangle1 {
    constructor(height, width) {
      (this.height = height), (this.width = width);
    }
    area() {
      console.log(`The area of the rectangle is ${this.height * this.width}`);
    }
  }
  const rectangleobj1 = new Rectangle1(7, 5);
  rectangleobj1.area();
  // Now let's the base class inherit into drive class
  class Square extends Rectangle1 {
    constructor(side) {
      super(side, side);
    }
  }
  //Now method override 
  rectangleobj1.area = function(){console.log('this is new method')}
  rectangleobj1.area();
  const square1 = new Square(5);
  square1.area();
  
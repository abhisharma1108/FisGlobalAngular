let printSquare = function (value) {
    return value * value;
  };

  //console.log(printSquare(25));
  
  // Arrow Function | Lambda Express in C#
  let printSquare_arrow = (value) => value * value;
  
  let printSquare_arrow2 = (value) => {
    return value * value;
  };
  //console.log(printSquare_arrow2(25));
  let printSomething = () => console.log("Something to be print");
  
  printSomething();
  
  let Addition = (value1, value2) => value1 + value2;
  console.log(Addition(10, 20));
  let ComplexFunction = () => {
    for (let index = 1; index <= 10; index++) {
      console.log(index);
    }
  };
  //ComplexFunction();
  
  const obj = {
    traditionalFunction: function () {
      console.log("traditional function", this);
    },
    arrowfunction: () => {
      console.log("arrow function", this);// pointing to current object
    },
    lastName: "Sharma",
  };
  
  obj.arrowfunction();
  obj.traditionalFunction(); 
  console.log('this enviroment',this);// pointing to null object
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-block-right',
  templateUrl: './text-block-right.component.html',
  styleUrls: ['./text-block-right.component.css']
})
export class TextBlockRightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

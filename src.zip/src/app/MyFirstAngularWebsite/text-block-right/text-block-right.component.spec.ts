import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TextBlockRightComponent } from './text-block-right.component';

describe('TextBlockRightComponent', () => {
  let component: TextBlockRightComponent;
  let fixture: ComponentFixture<TextBlockRightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TextBlockRightComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TextBlockRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

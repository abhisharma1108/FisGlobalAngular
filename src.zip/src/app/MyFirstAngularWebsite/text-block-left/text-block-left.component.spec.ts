import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TextBlockLeftComponent } from './text-block-left.component';

describe('TextBlockLeftComponent', () => {
  let component: TextBlockLeftComponent;
  let fixture: ComponentFixture<TextBlockLeftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TextBlockLeftComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TextBlockLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

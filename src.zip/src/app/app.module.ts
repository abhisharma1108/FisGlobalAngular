import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './MyFirstAngularWebsite/header/header.component';
import { TopNavbarComponent } from './MyFirstAngularWebsite/top-navbar/top-navbar.component';
import { TextBlockLeftComponent } from './MyFirstAngularWebsite/text-block-left/text-block-left.component';
import { TextBlockRightComponent } from './MyFirstAngularWebsite/text-block-right/text-block-right.component';
import { Bootstrap5DemoComponent } from './BootstrapDemo/bootstrap5-demo/bootstrap5-demo.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbootstrapdemoComponent } from './BootstrapDemo/ngbootstrapdemo/ngbootstrapdemo.component';
import { OneWayBindingComponent } from './BindingsDemo/one-way-binding/one-way-binding.component';
import { EventBindingComponent } from './BindingsDemo/event-binding/event-binding.component';
import { TwoWayBindingComponent } from './BindingsDemo/two-way-binding/two-way-binding.component';
import { FormsModule } from '@angular/forms';
import { NgIfDemoComponent } from './AttributeDirectivesDemo/ng-if-demo/ng-if-demo.component';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TopNavbarComponent,
    TextBlockLeftComponent,
    TextBlockRightComponent,
    Bootstrap5DemoComponent,
    NgbootstrapdemoComponent,
    OneWayBindingComponent,
    EventBindingComponent,
    TwoWayBindingComponent,
    NgIfDemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngbootstrapdemo',
  templateUrl: './ngbootstrapdemo.component.html',
  styleUrls: ['./ngbootstrapdemo.component.css']
})
export class NgbootstrapdemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NgbootstrapdemoComponent } from './ngbootstrapdemo.component';

describe('NgbootstrapdemoComponent', () => {
  let component: NgbootstrapdemoComponent;
  let fixture: ComponentFixture<NgbootstrapdemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NgbootstrapdemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NgbootstrapdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

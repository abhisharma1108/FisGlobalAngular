class Customer {
    constructor() {
        this.CustomerName = "";
        this._CustomerDesignation = "";
    }
    set CustomerDesignation(value) {
        if (value.length == 0) {
            throw "Customer designation is required";
        }
        this._CustomerDesignation = value;
    }
    get CustomerDesignation() {
        return this._CustomerDesignation;
    }
    validate() {
        alert("void test");
    }
    validatereturn() {
        alert("return test");
        return true;
    }
    validateWithpara(input) {
        alert("return test with param");
        return true;
    }
}
class SomeOtherCustomer extends Customer {
    validate() {
        alert("this is a new customer");
    }
}

import { Address } from "./Address";

interface IDal{

    Add();
}


class Customer implements IDal {

    Add() {
        throw new Error("Method not implemented.");
    }
    public CustomerName: string = "";
public addressobj : Address = new Address();


private _CustomerDesignation : string = "";
public set CustomerDesignation (value : string){

    if(value.length==0)
    {
        throw "Customer designation is required";
    }
    this._CustomerDesignation= value;
}

public get CustomerDesignation(){
    return this._CustomerDesignation;
}

    validate() {
        alert("void test");
    }
   public validatereturn() {
        alert("return test");
        return true;
    }
  public  validateWithpara(input: number): boolean {

        alert("return test with param");
        return true;
    }
}
class SomeOtherCustomer extends Customer
{
public   validate() {
        alert("this is a new customer");
    }

}

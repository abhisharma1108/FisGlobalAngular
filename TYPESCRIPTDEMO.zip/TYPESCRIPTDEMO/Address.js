"use strict";
exports.__esModule = true;
exports.Address = void 0;
var Address = /** @class */ (function () {
    function Address() {
        this.Street1 = "";
    }
    return Address;
}());
exports.Address = Address;

class Customer {
    public CustomerName: string = "";
    validate() {
        alert("void test");
    }
   public validatereturn() {
        alert("return test");
        return true;
    }
  public  validateWithpara(input: number): boolean {

        alert("return test with param");
        return true;
    }
}
class SomeOtherCustomer extends Customer
{
public   validate() {
        alert("this is a new customer");
    }

}

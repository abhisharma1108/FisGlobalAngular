class Customer
{
public CustomerName : string="";
}
var Customer = /** @class */ (function () {
    function Customer() {
        this.CustomerName = "";
    }
    return Customer;
}());

export class Address {

    public Street1  : string="";
    
}
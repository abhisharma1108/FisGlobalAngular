let a="Abhishek";
let b="sharma"

console.log(a+" "+b);
